import React, { useState } from 'react';
import './log.css';
import { Link } from 'react-router-dom';

const Login = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    if (username === 'Weather' && password === 'W@123') {
      onLogin(true);
    } else {
      setError('Invalid username or password');
    } 
  };
  return (
    <div className="login">
        <fieldset>
      <h1>Login Page</h1>
      <hr></hr>
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleLogin}>
        <div className="form-group">
          <label>Username:</label>
          <input className='ncolor' type="text" value={username} onChange={(e) => setUsername(e.target.value)} required />
        </div>
        <div className="form-group">
          <label>Password:</label>
          <input className='pcolor' type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </div><br></br>
        <Link to ='/login'>
        <button className='bcolor' type="submit">Login</button></Link>
      </form>
      <p>please login to get the weather details</p>
      </fieldset>
    </div>
  );
};
export default Login;

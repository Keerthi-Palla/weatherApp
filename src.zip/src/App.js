import React from "react";
import './log.css';
import Login from './log.js';
import Weather from "./weather.js";
import { BrowserRouter as Router,Route,Routes } from "react-router-dom";
function App(){
  return(
    <Router>
      <Routes>
        <Route path="/"element={<Login></Login>}/>
        <Route path="/Login"element={<Weather/>}>
        </Route>
      </Routes>
    </Router>
  );
}
export default App;
import React from 'react';
function Login(){
    return(
        <div className='d-flex justify-content-center align-items-center bg-black vh-100'>
            <div className='bg-white p-3 rounded w-25'>
                <h1>Sign-In</h1>
                <form onSubmit={handleSubmit}>
                    <div>
                        <label htmlFor='email'>Email</label>
                        <input type="email" placeholder='Enter Email' name='email'
                        onChange={handleInput} className='form-control rounded-0'></input>
                        {errors.email && <span className='text-danger'>error.email</span>}
                    </div>
                    <div>
                        <label htmlFor='password'>Password</label>
                        <input type="password" placeholder='Enter password' name='password'
                        onChange={handleInput} className='form-control rounded-0'></input>
                        {errors.password && <span className='text-danger'>error.password</span>}
                    </div>
                    <br/>
                    <button type='submit' className='btn btn-success w-100 rounded-0'><strong>Log In</strong></button>
                    <p>you are agree to out terms and policies</p> 
                    <Link to='/signup' className='btn btn-default border w-100 bg-light rounded-0'><strong>Create Account</strong></Link>
                </form>
            </div>
        </div>
    );
}
export default Login;

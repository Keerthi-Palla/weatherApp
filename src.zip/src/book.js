import React from "react";

class Bookshop extends React.Component{
    render(){
        return(
            <fieldset>
                <h1 class="con">Bookshop</h1>
      <hr/>
      <div class="shadow p-3 mb-5 bg-body-tertiary rounded">
        <div class="shadow p-3 mb-5 bg-body-tertiary rounded">
          <span class="input-group-text" id="inputGroup-sizing-default">book id </span>
          <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
        </div>
          <br/>
          <div class="input-group mb-4">
            <span class="input-group-text" id="inputGroup-sizing-default">Title </span>
            <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
          </div>
          <br/>
          <div class="input-group mb-4">
            <span class="input-group-text" id="inputGroup-sizing-default">Author first name </span>
            <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
          </div>
          <br></br>
          <div class="input-group mb-4">
            <span class="input-group-text" id="inputGroup-sizing-default">Author last name </span>
            <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
          </div>
          <br></br>
          <div class="input-group mb-4">
            <span class="input-group-text" id="inputGroup-sizing-default">Released year </span>
            <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
          </div>
          <br></br>
          <div class="input-group mb-4">
            <span class="input-group-text" id="inputGroup-sizing-default">Stock quantity </span>
            <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
          </div>
          <br></br>
          <div class="input-group mb-4">
            <span class="input-group-text" id="inputGroup-sizing-default">pages </span>
            <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/>
          </div>
        </div>          
      <br/><br/>
         <div class="center">
          <button type="submit" class="btn btn-primary btn-lg">submit</button>
         </div>              
        </fieldset>
        );
    }
}
export default Bookshop;
const express = require('express');
const axios = require('axios');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const port = 5000;

const apiKey = process.env.REACT_APP_WEATHER_API_KEY;

console.log(apiKey);

if (!apiKey) {
    console.error('No API key found! Please set the REACT_APP_WEATHER_API_KEY environment variable.');
    process.exit(1);
}

const weatherApiUrl = "http://api.openweathermap.org/data/2.5/weather";

app.get('/weather', async (req, res) => {
    const { lat, lon } = req.query;
    console.log(`Received request for weather data at lat: ${lat}, lon: ${lon}`);
    try {
        const response = await axios.get(`${weatherApiUrl}?lat=${lat}&lon=${lon}&appid=${apiKey}`);
        console.log('Weather data retrieved:', response.data);
        res.json(response.data);
    } catch (error) {
        console.error('Error fetching weather data:', error.message);
        if (error.response) {
            console.error('Response data:', error.response.data);
        }
        res.status(500).send('Internal server error. Please check server logs for more details.');
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
